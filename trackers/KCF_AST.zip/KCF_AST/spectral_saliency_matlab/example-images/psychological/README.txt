These images were presented in "Center-surround Divergence of Feature 
Statistics for Salient Object Detection" by D. A. Klein and S. Frintrop. If
you use these images in your work, please be so kind as to cite the related
publication [1].

  [1] "Center-surround Divergence of Feature Statistics for Salient Object
      Detection", Dominik A. Klein and S. Frintrop. Proc. Int. Conf. Comp.
      Vis. (ICCV), November 6-13, 2011, Barcelona, Spain